require "colorize" #for adding colours to output in console
module AllMains
    ##
    # The function takes in the folder name and year as input and returns the maximum temperature, minimum
    # temperature and maximum humidity of the given year
    # 
    # Args:
    #   folder_name: The name of the folder that contains the data files.
    #   year: The year for which you want to find the highest and lowest temperatures and the highest
    # humidity.
    def e_hash_func(folder_name, year)

            max_hash_array = Hash.new {|h,k| h[k]=""} #hash that contains max temp of every month in given year
            min_hash_array = Hash.new {|h,k| h[k]=""} #hash that contains min temp of every month in given year
            max_humidity_array = Hash.new{|h,k| h[k]=""} #hash that contains max humidity of every month in given year

            text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Jan.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i()) #storing the max temperature date based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i()) #storing the min temperature date based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Feb.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i()) #storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])



        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Mar.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        
        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Apr.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_May.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])


        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Jun.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])


        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Jul.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Aug.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])


        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Sep.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Oct.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Nov.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])


        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + "_Dec.txt", "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i())#storing the max value based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i())#storing the min temperature value based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #return hash_array
        #return hash_array.max_by{|k,v| v}
        max_hash_array.store(hash_array.max_by{|k,v| v}[0], hash_array.max_by{|k,v| v}[1])
        min_hash_array.store(hash_array1.min_by{|k,v| v}[0], hash_array1.min_by{|k,v| v}[1])
        max_humidity_array.store(hash_array2.max_by{|k,v| v}[0], hash_array2.max_by{|k,v| v}[1])

        puts ("Highest: " + max_hash_array.max_by{|k,v| v}[1].to_s() + "C" + " on " + max_hash_array.max_by{|k,v| v}[0].to_s())# max_hash_array containing max temperature of each month of given year of given city
        puts ("Lowest: " + min_hash_array.min_by{|k,v| v}[1].to_s() + "C" + " on " + min_hash_array.min_by{|k,v| v}[0].to_s())# min_hash_array containing min temperature of each month of given year of given city
        puts ("Highest Humidity: " + max_humidity_array.max_by{|k,v| v}[1].to_s() + "%" + " on " + max_humidity_array.max_by{|k,v| v}[0].to_s())# min_hash_array containing min temperature of each month of given year of given city
    end


    #Integer month to string month file converter
    ##
    # It takes an integer between 1 and 12 and returns the corresponding month as a string
    # 
    # Args:
    #   month_int: The month you want to get the data for.
    # 
    # Returns:
    #   A string that is the name of the file that will be created.
    def num_to_string(month_int)
        
        if(month_int <= 12 and month_int > 0)
            if(month_int == 1)
                return "_Jan.txt"
            elsif(month_int == 2)
                return "_Feb.txt"
            elsif(month_int == 3)
                return "_Mar.txt"
            elsif(month_int == 4)
                return "_Apr.txt"
            elsif(month_int == 5)
                return "_May.txt"
            elsif(month_int == 6)
                return "_Jun.txt"
            elsif(month_int == 7)
                return "_Jul.txt"
            elsif(month_int == 8)
                return "_Aug.txt"
            elsif(month_int == 9)
                return "_Sep.txt"
            elsif(month_int == 10)
                return "_Oct.txt"
            elsif(month_int == 11)
                return "_Nov.txt"
            else
                return "_Dec.txt"
            end
        end
    end

    ##
    # If the month is between 1 and 12, return the name of the month
    # 
    # Args:
    #   month_int: The month number (1-12)
    # 
    # Returns:
    #   The name of the month.
    def month_to_name(month_int)
        if(month_int <= 12 and month_int > 0)
            if(month_int == 1)
                return "January"
            elsif(month_int == 2)
                return "February"
            elsif(month_int == 3)
                return "March"
            elsif(month_int == 4)
                return "April"
            elsif(month_int == 5)
                return "May"
            elsif(month_int == 6)
                return "June"
            elsif(month_int == 7)
                return "July"
            elsif(month_int == 8)
                return "August"
            elsif(month_int == 9)
                return "September"
            elsif(month_int == 10)
                return "October"
            elsif(month_int == 11)
                return "November"
            else
                return "December"
            end
        end
    end

    ##
    # This function takes in a folder name, year and month and prints out the temperature data for that
    # month in a readable format
    # 
    # Args:
    #   folder_name: the name of the folder that contains the text files
    #   year: the year you want to see the data for
    #   month: the month you want to see the data for
    def c_array_func(folder_name, year, month)
        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + num_to_string(month), "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end

        puts(month_to_name(month) + " " + year.to_s() + "\n")

        array = Array.new()
        index = 24
        day_count = 1
        i=1
        while(i<=31*2)

            array[i] = text_file[index]
            array[i + 1] = text_file[index + 3] 
            print(day_count.to_s() + " ")#putting day of month

            count = 0
            while(count < array[i+1].to_i())
                print "+".blue()
                count+=1
            end

            count = 0
            while(count < array[i].to_i())
                print "+".red()
                count+=1
            end
            print (" " + array[i+1] + "C" + " - " + array[i] + "C" + "\n")

            index += 23
            day_count+=1
            i+=2
        end

    end

    ##
    # This function takes in the folder name, year and month as input and returns the average of max
    # temperature, min temperature and max humidity
    # 
    # Args:
    #   folder_name: The name of the folder that contains the data files.
    #   year: The year of the file you want to open.
    #   month: The month of the year (1-12)
    def a_hash_func(folder_name, year, month)
        text_file = []
            File.open(folder_name + "/" + folder_name + "_" + year.to_s() + num_to_string(month), "r") do |f|
                f.each_line do |line|
                arr = line.split(',')
                arr.each do |word|
                text_file << word
                end  
            end
        end
        index = 23
        hash_array = {}
        hash_array1 = {}
        hash_array2 = {}
        i=0
        while(i<31)
            hash_array.store(text_file[index], text_file[index+1].to_i()) #storing the max temperature date based pair in whole month(31 days(max)) 
            hash_array1.store(text_file[index], text_file[index+3].to_i()) #storing the min temperature date based pair in whole month(31 days(max))
            hash_array2.store(text_file[index], text_file[index+7].to_i()) #storing the max humidity date based pair in whole month(31 days(max))
            index = index + 23
            i+=1
        end
        #finding average of max temp, min temp, max humidity
        sum_value1 = hash_array.values.sum / hash_array.length()
        sum_value2 = hash_array1.values.sum / hash_array1.length()
        sum_value3 = hash_array2.values.sum / hash_array2.length()

        puts ("Highest Average: " + sum_value1.to_s() + "C")
        puts ("Lowest Average: " + sum_value2.to_s() + "C")
        puts ("Average Humidity: " + sum_value3.to_s() + "%")
        
    end


    #e_hash_func("Dubai_weather", 2007)  
    #puts(".............................")
    #a_hash_func("Dubai_weather", 2007, 3)
    #puts(".............................")
    #c_array_func("Dubai_weather", 2010, 9)

    #begin
end
