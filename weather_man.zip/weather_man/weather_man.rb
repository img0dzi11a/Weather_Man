# This is the main file that is run when the program is executed. It takes in the command line
# arguments and then calls the appropriate function in the hash.rb file.
require_relative "hash"
include AllMains
require "colorize"

if(ARGV.length > 0)
        type = ARGV[0]
        date = ARGV[1].split("/")
        folder = date[2]
        if(type.include?("-a"))
            AllMains::a_hash_func(folder.to_s, date[0].to_i, date[1].to_i)
        elsif(type.include?("-c"))
            AllMains::c_array_func(folder.to_s, date[0].to_i, date[1].to_i)
        elsif(type.include?("-e"))
            AllMains::e_hash_func(date[1], date[0].to_i)
        else
            puts "Invalid Data...".red()
        end
else
    puts "Invalid Data...".red()
end




  

